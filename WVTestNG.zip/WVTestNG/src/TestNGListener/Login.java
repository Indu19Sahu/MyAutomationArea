package TestNGListener;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;


@Listeners(TestNGListener.Listener.class)//Class level listener.
public class Login {
  @Test
  public void loginByFacebook() {
	  
	  System.out.println("This is a learning for report generation");
	  WebDriver driver = new FirefoxDriver();
	  driver.manage().window().maximize();
	  driver.get("http://www.google.co.in");
	  System.out.println(driver.getTitle());
	  driver.close();
	  
	 
  }
}
