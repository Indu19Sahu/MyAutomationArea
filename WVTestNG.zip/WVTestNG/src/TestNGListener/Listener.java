package TestNGListener;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.Test;

public class Listener implements ITestListener{
	
  @Test
  public void f() {
  }

  //These all method will be called when it needed lets say if test case gets fail then ontestfailed method will be called and rest of the 
  //method will not. And onteststart method will be called by default on every executiong of test scripts.
  
  
@Override
public void onTestStart(ITestResult result) {
	// TODO Auto-generated method stub
	System.out.println("Test is started and the details is" + result.getName());
}

@Override
public void onTestSuccess(ITestResult result) {
	// TODO Auto-generated method stub
	System.out.println("Test is Succeeded and the details is" + result.getName());
}

@Override
public void onTestFailure(ITestResult result) {
	// TODO Auto-generated method stub
	System.out.println("Test is failed and the details is" + result.getName());
}

@Override
public void onTestSkipped(ITestResult result) {
	// TODO Auto-generated method stub
	System.out.println("Test is skipped and the details is" + result.getName());
}

@Override
public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
	// TODO Auto-generated method stub
	
}

@Override
public void onStart(ITestContext context) {
	// TODO Auto-generated method stub
	
}

@Override
public void onFinish(ITestContext context) {
	// TODO Auto-generated method stub
	
}


}
