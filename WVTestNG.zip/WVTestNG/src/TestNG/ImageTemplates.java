package TestNG;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class ImageTemplates {
	
	WebDriver driver;
	
	
	
  @Test
  public void PrintingLabels() throws InterruptedException {
	  
	  driver.findElement(By.xpath(".//*[@id='iFrameFirstDiv']/div[4]/div[3]/div[2]/button[2]")).click();
      System.out.println("Personalize Screen-Next button hass been clicked");
      //driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
      Thread.sleep(20000);
    
      //Checking whether checkboxes are checked or not. If it is checked then only I can click on next button.
      
      driver.findElement(By.xpath(".//*[@id='checkList']/div[1]")).click();
      System.out.println("Preview Screen-1st checkbox hass been clicked");
      driver.findElement(By.xpath(".//*[@id='checkList']/div[2]")).click();
      System.out.println("Preview Screen-2nd checkbox hass been clicked");
      driver.findElement(By.xpath(".//*[@id='checkList']/div[3]")).click();
      System.out.println("Preview Screen-3rd checkbox hass been clicked");
      driver.findElement(By.xpath(".//*[@id='checkList']/div[4]")).click();
      System.out.println("Preview Screen-4th checkbox hass been clicked");
      driver.findElement(By.xpath(".//*[@id='mainPrintableAreaWrapper']/div[2]/div[4]/div[2]/a")).click();
      System.out.println("Label is being printed");
      Thread.sleep(20000);
      SaveLabels();
      
  }
  
  public void SaveLabels() throws InterruptedException{
	  driver.findElement(By.xpath(".//*[@id='iFrameFirstDiv']/div[4]/div[4]/div[2]/button")).click();
      Thread.sleep(15000);
      driver.findElement(By.xpath(".//*[@id='saveShareArea']/div/div/div[5]/button")).click();
      driver.findElement(By.xpath(".//*[@id='userSaveLabelLabelName']")).sendKeys("LMAutomationTesting");
      driver.findElement(By.xpath(".//*[@id='userSaveLabel']/div[3]/button")).click();
      Thread.sleep(15000);
      System.out.println("Label has been saved");
     
   //Perform the click operation that opens new window
      driver.findElement(By.xpath(".//*[@id='saveShareArea']/div/div/div[4]/span[1]/span[1]/img")).click();
      Thread.sleep(10000);
  	 System.out.println(driver.getTitle());
  	 
       //driver.switchTo().frame("facebook");
  	 String parent = driver.getWindowHandle();
  	 Set<String> allwindows=driver.getWindowHandles();
  	 int count = allwindows.size();
  	 System.out.println("Total window "+count);
  	 for(String child:allwindows){
  		 if(!parent.equalsIgnoreCase(child)){		    			 
  			 driver.switchTo().window(child);
  		 }
  	 }
       
      driver.findElement(By.xpath(".//*[@id='email']")).sendKeys("indu.sahu19nov@gmail.com");
      driver.findElement(By.xpath(".//*[@id='pass']")).sendKeys("FB#maindu19@Amit");
      driver.findElement(By.xpath(".//*[@id='loginbutton']")).click();
      System.out.println("Fetching data from the Facebook");
      Thread.sleep(10000);
      //driver.findElement(By.xpath(".//*[@id='u_0_1t']")).click();
      //ToCancel facebook sharing
      driver.findElement(By.xpath(".//*[@id='u_0_1s']")).click();
      driver.switchTo().alert().accept();
      System.out.println("Alert has been closed.");
      Thread.sleep(5000);
      driver.switchTo().window(parent);
      System.out.println(driver.getTitle());
      System.out.println("Swithced back to parent window");
      Thread.sleep(30000);
      driver.findElement(By.xpath(".//*[@id='iFrameFirstDiv']/div[4]/div[5]/div[2]/button[3]")).click();
      
  }
}
