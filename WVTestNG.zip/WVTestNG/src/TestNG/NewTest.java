package TestNG;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestNGListener;
import org.testng.annotations.Test;
import org.testng.internal.annotations.IListeners;

public class NewTest {

	private static final TimeUnit SECONDS = null;
	public WebDriver driver = new FirefoxDriver();
	String parent = null;

	public void ParentWindow() {
		parent = driver.getWindowHandle();
		System.out.println(driver.getTitle() + parent);
	}

	public void CloseTabHandle() {
		//This is because pop-up does not open everytime. sometimes it gets opened and sometimes not.
		
		try{
			
				if (driver.findElement(By.xpath(".//*[@id='ltkmodal-contentarea']")).isEnabled()) {
					System.out.println("pop-up is being displayed");
					driver.findElement(By.xpath(".//*[@id='close-button']")).click();
				}
			
		}
		catch(NoSuchElementException e) {
            System.out.println("pop-up is not being displayed");
            e.printStackTrace();
		}

	}
	
	public void waitForPageLoaded() {
        ExpectedCondition<Boolean> expectation = new
                ExpectedCondition<Boolean>() {
                    public Boolean apply(WebDriver driver) {
                        return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");
                    }
                };
        try {
            Thread.sleep(1000);
            WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(expectation);
        } catch (Throwable error) {
            Assert.fail("Timeout waiting for Page Load Request to complete.");
        }
    }
	
	public void iFrameLoaded(){
		
		Set<String> newWindow = driver.getWindowHandles();
		
		for(String singleWindow : newWindow){
			driver.switchTo().window(singleWindow);		
			
		}
		waitForPageLoaded();
		
	}

	@SuppressWarnings("unchecked")
	@Test
	public void main() throws InterruptedException {

		try {
			driver.get("https://windsorvineyards-windsorstage.coresense.com/all-personalizable-labels");
			System.out.println(driver.getTitle());
			driver.manage().deleteAllCookies();// Deleting all cookies becoze sometimes this was launching browser only and doing nothing.

			// Need to call closeTabhandle function to close pop-up.
			CloseTabHandle();
			// To get handle on current opened window and fetch their id.
			ParentWindow();
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

			//**************************COUNT_OF_LABELS*********************************

			//Thread.sleep(10000);
			List<WebElement> listofElements = driver.findElements(By.xpath("//*[@class='col-xs-12']/a"));//this is relative xpath of "html/body/div[4]/div/div[2]/div/div/div/a"(this is a absolute xpath)
			System.out.println("No. of Labels: " + listofElements.size());
			System.out.println("*************************************************************");
			for (int elementIndex = 1; elementIndex < 3; elementIndex++) {
				
				WebElement array_element = (WebElement) listofElements.get(elementIndex);
					
				String link = array_element.getAttribute("href");				
						
				// System.out.println("hello");
				System.out.println("Opening a new window");
				String selectLinkOpeninNewTab = Keys.chord(Keys.CONTROL, "n");
				array_element.sendKeys(selectLinkOpeninNewTab);
				
				Set<String> newWindow = driver.getWindowHandles();
				
				for(String singleWindow : newWindow){
					driver.switchTo().window(singleWindow);		
					
				}
				//array_element.sendKeys(selectLinkOpeninNewTab);
				driver.navigate().to(link);		
				driver.manage().deleteAllCookies();// Deleting all cookies becoze sometimes this was launching browser only and doing nothing.
				CloseTabHandle();
				//waitForPageLoaded();
				iFrameLoaded();
				System.out.println(driver.getTitle() + driver.getWindowHandle());
				System.out.println("*************************************************************");
				driver.switchTo().window(parent);
				
				}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
}
