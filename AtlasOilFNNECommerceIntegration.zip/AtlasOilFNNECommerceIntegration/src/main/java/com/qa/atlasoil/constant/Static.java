package com.qa.atlasoil.constant;
/**
 * @author Garima Burad
 *
 */
public class Static {

	public static final String CONFIGERATION_PROPERTIES_FILE_PATH = ".//src//main//resources//config//main_config.properties";
	public static final String DOWNLOADED_FILES = "Downloaded_File";
	public static final String USER_DIR = "user.dir";
	public static final String PREFERED_DOWNLOAD_DIRECTORY = "prefs";

}
