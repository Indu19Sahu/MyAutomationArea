/**
 * 
 */
/**
 * @author Techment Technology
 *
 */
package com.qa.atlasoil.constant;