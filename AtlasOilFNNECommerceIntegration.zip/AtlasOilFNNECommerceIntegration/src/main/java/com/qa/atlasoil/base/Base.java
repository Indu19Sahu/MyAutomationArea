/**
 * Contains 
 */

package com.qa.atlasoil.base;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterSuite;

import com.qa.atlasoil.constant.Field;
import com.qa.atlasoil.constant.Static;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import java.util.HashMap;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class Base {
	public static Properties mainconfig;
	public static Properties webconfig;
	public static Properties jsonconfig;
	public static Properties payloadconfig;
	public static WebDriver webdriver;
	public static String token;

	/*
	 * Creating a folder inside the project to store downloading files
	 */
	static File downloadedFiles = new File(System.getProperty(Static.USER_DIR), Static.DOWNLOADED_FILES);
	public static String DownloadFilepath = downloadedFiles.getAbsolutePath();

	/*
	 * Initializing Properties
	 */

	public static void initializeProperty() {

		try {
			mainconfig = new Properties();
			FileInputStream fis = new FileInputStream(Static.CONFIGERATION_PROPERTIES_FILE_PATH);
			mainconfig.load(fis);

			webconfig = new Properties();
			FileInputStream config_path = new FileInputStream(mainconfig.getProperty(Field.WEB_CONFIG));
			webconfig.load(config_path);

			jsonconfig = new Properties();
			FileInputStream jsonconfig_path = new FileInputStream(mainconfig.getProperty(Field.JSON_CONFIG));
			jsonconfig.load(jsonconfig_path);

			payloadconfig = new Properties();
			FileInputStream payloadconfig_path = new FileInputStream(mainconfig.getProperty(Field.PAYLOAD_CONFIG));
			payloadconfig.load(payloadconfig_path);

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	/*
	 * Initializing Webdriver
	 */
	public WebDriver initializedriver() throws IOException {

		initializeProperty();

		// Initializing Chrome driver
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		HashMap<String, Object> chromePref = new HashMap<String, Object>();
		chromePref.put(Field.CHROME_DOWNLOAD_DEFAULT_DIRECTORY, DownloadFilepath);
		options.setExperimentalOption(Static.PREFERED_DOWNLOAD_DIRECTORY, chromePref);
		webdriver = new ChromeDriver(options);

		webdriver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		webdriver.manage().window().maximize();
		return webdriver;

	}

	@AfterSuite
	public void teardown() {
		webdriver.close();
	}

}
