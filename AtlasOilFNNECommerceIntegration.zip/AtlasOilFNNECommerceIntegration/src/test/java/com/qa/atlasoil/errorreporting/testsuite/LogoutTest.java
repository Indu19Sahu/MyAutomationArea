package com.qa.atlasoil.errorreporting.testsuite;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;
import com.qa.atlasoil.base.Base;
import com.qa.atlasoil.errorreporting.pageobject.Dashboard;
import com.qa.atlasoil.errorreporting.pageobject.Login;
import com.qa.atlasoil.reports.ExtentReport;

public class LogoutTest extends ExtentReport {
	Base base = new Base();
	public static Logger log = LogManager.getLogger(ExtentReport.class.getName());

	Login login;
	Dashboard dashboard;
//   @Override
//   public void run(IHookCallBack callBack, ITestResult testResult) {
//		// TODO Auto-generated method stub
//		String testMethodName = testResult.getMethod().getMethodName();
//       if (methodsToRun.contains(testMethodName)) {
//           System.out.println("About to run " + testResult.getMethod().getMethodName());
//           callBack.runTestMethod(testResult);
//       } else {
//           testResult.setStatus(ITestResult.SKIP);
//           throw new SkipException(testResult.getMethod().getMethodName()+": Method Skipped");
//       }
//	}

	@BeforeTest
	public void initialize() throws IOException {
		base.initializedriver();
		System.out.println("Driver is initizlized");
		System.out.println("Navigate");
		// methodsToRun = Base.webAccessTestCase();
	}

	@Test
	public void logout() throws IOException, InterruptedException {
		Base.webdriver.get(Base.webconfig.getProperty("url"));
		test = extent.createTest("Logout Test");
		login = new Login(Base.webdriver);
		// ArrayList<String> a=b.webaccess("Login");
		login.SendEmail();
		login.SendPassword();
		login.Submit();
		test.log(Status.INFO, "Successfull login");
		Thread.sleep(5000);
		dashboard = new Dashboard(Base.webdriver);

		dashboard.logout();
		Thread.sleep(5000);
		test.log(Status.INFO, "Successfull logout");

		dashboard.logout_assertion();
		test.log(Status.INFO, "Logout assert");

	}

	@AfterSuite
	public void teardown() {
		Base.webdriver.close();
	}

}
