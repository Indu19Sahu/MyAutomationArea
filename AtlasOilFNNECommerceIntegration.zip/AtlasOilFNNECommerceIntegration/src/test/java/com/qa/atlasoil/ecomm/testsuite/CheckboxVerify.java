package com.qa.atlasoil.ecomm.testsuite;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.qa.atlasoil.base.Base;
import com.qa.atlasoil.constant.Field;
import com.qa.atlasoil.ecomm.pageobject.AtlasSite;
import com.qa.atlasoil.reports.ExtentReport;

public class CheckboxVerify extends ExtentReport {
	Base base = new Base();

	AtlasSite atlas;
	public static Logger log = LogManager.getLogger(ExtentReport.class.getName());

	@BeforeTest
	public void initialize() throws IOException {
		base.initializedriver();
		System.out.println("Driver is initizlized");
	}

	@Test
	public void checkboxAvailibilty() throws IOException, InterruptedException {
		Base.webdriver.get(Base.webconfig.getProperty(Field.ATLAS_URL));

		System.out.println("Navigate to Atlas Site");

		test = extent.createTest("checkboxAvailibilty Test");

		atlas = new AtlasSite(Base.webdriver);
		atlas.accept();
		test.log(Status.INFO, "Clicked Accpet of T&C popup");

		atlas.Login();
		test.log(Status.INFO, "Clicked on Login option");
		Thread.sleep(5000);

		atlas.email();
		test.log(Status.INFO, "Entered registered email address");

		atlas.password();
		test.log(Status.INFO, "Entered registered password");

		atlas.Login_button();
		test.log(Status.INFO, "Clicked on Login button");

		atlas.assertion();
		test.log(Status.INFO, "Successfull login and assert");

		atlas.view_orderHistory();
		test.log(Status.INFO, "Cliked on View Order History option");

		Assert.assertTrue(Base.webdriver.getTitle().contains("Order History"), "Wrong page");
		test.log(Status.INFO, "Successfully Assert View Order History page");
		Thread.sleep(10000);

		atlas.accesOrderNumber();
		test.log(Status.INFO, "Go to Desired orderNumber");
		Thread.sleep(5000);

		atlas.assert_checkbox_forOrdeNumber_notavailable();
		Thread.sleep(5000);

	}
	@AfterTest
	public void teardown() {
		Base.webdriver.close();
	}

}
