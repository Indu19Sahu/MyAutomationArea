package com.qa.atlasoil.ecomm.testsuite;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.qa.atlasoil.base.Base;
import com.qa.atlasoil.constant.Field;
import com.qa.atlasoil.ecomm.pageobject.AtlasSite;
import com.qa.atlasoil.reports.ExtentReport;

public class DownloadCheckedOrder extends ExtentReport {
	Base base = new Base();

	AtlasSite atlas;
	public static Logger log = LogManager.getLogger(ExtentReport.class.getName());

	@BeforeTest
	public void initialize() throws IOException {
		base.initializedriver();
		System.out.println("Driver is initizlized");
	}

	@Test
	public void downloadCheckedOrder() throws IOException, InterruptedException {
		Base.webdriver.get(Base.webconfig.getProperty(Field.ATLAS_URL));
		System.out.println("Navigate to Atlas Site");
		test = extent.createTest("DownloadCheckedOrder Test");
		atlas = new AtlasSite(Base.webdriver);
		atlas.accept();
		test.log(Status.INFO, "Clicked Accpet of T&C popup");

		atlas.Login();
		test.log(Status.INFO, "Clicked on Login option");
		Thread.sleep(5000);

		atlas.email();
		test.log(Status.INFO, "Entered registered email address");

		atlas.password();
		test.log(Status.INFO, "Entered registered password");

		atlas.Login_button();
		test.log(Status.INFO, "Clicked on Login button");

		atlas.assertion();
		test.log(Status.INFO, "Successfull login and assert");

		atlas.view_orderHistory();
		test.log(Status.INFO, "Cliked on View Order History option");

		Assert.assertTrue(Base.webdriver.getTitle().contains("Order History"), "Wrong page");
		test.log(Status.INFO, "Successfully Assert View Order History page");
		Thread.sleep(10000);

		atlas.view_orderHistory();
		Thread.sleep(10000);

		atlas.accesOrderNumber();
		test.log(Status.INFO, "Go to Desired orderNumber");
		Thread.sleep(5000);

		atlas.click_checkbox_oderNumber1();
		test.log(Status.INFO, "Clicked on Desired order number");
		Thread.sleep(5000);

		atlas.click_to_all_download();
		test.log(Status.INFO, "Clicked on Download BOL nd DT button");
		Thread.sleep(10000);

		atlas.unzip();
		test.log(Status.INFO, "UnZipping the Downloaded File");
		Thread.sleep(15000);

		atlas.compare();
		test.log(Status.INFO, "Comparing the downloaded file with expected file");
		Thread.sleep(15000);
	}

	@AfterTest
	public void teardown() {
		try {
			FileUtils.forceDelete(new File(Base.DownloadFilepath));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Base.webdriver.close();
	}

}
