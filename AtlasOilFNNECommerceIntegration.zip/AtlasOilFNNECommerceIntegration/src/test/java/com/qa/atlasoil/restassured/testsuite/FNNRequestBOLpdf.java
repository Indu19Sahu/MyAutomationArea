package com.qa.atlasoil.restassured.testsuite;

import com.aventstack.extentreports.Status;
import com.qa.atlasoil.base.Base;
import com.qa.atlasoil.constant.Field;
import com.qa.atlasoil.reports.ExtentReport;
import com.qa.atlasoil.util.jsonGenerator.BOLPdfJsonGenerator;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class FNNRequestBOLpdf extends ExtentReport {
	Base base = new Base();
	BOLPdfJsonGenerator bol_pdf = new BOLPdfJsonGenerator();
	@Test
	public void post() throws IOException {
		Base.initializeProperty();

		try {
			test = extent.createTest("Sending BOL(pdf) Test");
			RestAssured.baseURI = Base.payloadconfig.getProperty(Field.ENDPOINT_DEV);

			bol_pdf.jsonGenerator();
			Thread.sleep(5000);
			GetAuthTokenForECommerce.getToken();
			
			String payload = new String(Files.readAllBytes(Paths.get(Base.mainconfig.getProperty(Field.JSON_PAYLOAD_PATH))));
			// System.out.println(payload);
			RequestSpecification request = RestAssured.given();
			
			request.header("Content-type", Field.CONTENT_TYPE);
			// request.header("aeg-sas-key",prop.getProperty("aeg-sas-key(dev)"));
			request.header("Ocp-Apim-Trace", "true");
			request.header("Ocp-Apim-Subscription-Key", Base.payloadconfig.getProperty(Field.SUBSCRIPTION_KEY_DEV));
			request.header("Authorization", "Bearer "+Base.token);
			request.body(payload);

			System.out.println("Creating BOL(pdf)");
			test.log(Status.INFO, "Creating BOL(pdf");
			Response response = request.post(Base.payloadconfig.getProperty(Field.RESOURCE_DEV));
			Thread.sleep(20000);
			
			int statusCode = response.getStatusCode();
			System.out.println("Status Code: " + statusCode);

			Assert.assertEquals(statusCode, 200);
			System.out.println("Successfully BOL(pdf) sent with status code 200");
			test.log(Status.PASS, "Successfully BOL(pdf) sent with status code 200");
			// String responseBody = response.getBody().asString();
			// System.out.print(responseBody);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
