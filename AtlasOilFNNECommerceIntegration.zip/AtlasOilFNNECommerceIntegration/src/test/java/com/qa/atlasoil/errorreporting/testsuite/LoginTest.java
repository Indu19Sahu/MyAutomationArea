package com.qa.atlasoil.errorreporting.testsuite;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterSuite;

import org.testng.annotations.BeforeTest;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.qa.atlasoil.base.Base;
import com.qa.atlasoil.errorreporting.pageobject.Login;
import com.qa.atlasoil.reports.ExtentReport;

public class LoginTest extends ExtentReport {
	Base base = new Base();
	public static Logger log = LogManager.getLogger(ExtentReport.class.getName());
	public static Base b1;

	Login login;

//   @Override
//   public void run(IHookCallBack callBack, ITestResult testResult) {
//		// TODO Auto-generated method stub
//		String testMethodName = testResult.getMethod().getMethodName();
//       if (methodsToRun.contains(testMethodName)) {
//           System.out.println("About to run " + testResult.getMethod().getMethodName());
//           callBack.runTestMethod(testResult);
//       } else {
//           testResult.setStatus(ITestResult.SKIP);
//           throw new SkipException(testResult.getMethod().getMethodName()+": Method Skipped");
//       }
//	}

	@BeforeTest
	public void initialize() throws IOException {
		base.initializedriver();
		System.out.println("Driver is initizlized");
		
		// methodsToRun = Base.webAccessTestCase();
	}

	@Test
	public void login() throws IOException, InterruptedException {

		Base.webdriver.get(Base.webconfig.getProperty("url"));
		System.out.println("Navigate to ErrorReporting Site");
		test = extent.createTest("Login Test");
		login = new Login(Base.webdriver);
		// ArrayList<String> a=b.webaccess("Login");
		login.SendEmail();
		login.SendPassword();
		login.Submit();
		test.log(Status.INFO, "Successfull login");
		Thread.sleep(5000);

		login.assertion();
		test.log(Status.INFO, "Login assert");

	}

	@AfterSuite
	public void teardown() {
		Base.webdriver.close();
	}

}
