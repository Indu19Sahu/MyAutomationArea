package com.qa.atlasoil.errorreporting.testsuite;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;
import com.qa.atlasoil.base.Base;
import com.qa.atlasoil.errorreporting.pageobject.Dashboard;
import com.qa.atlasoil.errorreporting.pageobject.Login;
import com.qa.atlasoil.reports.ExtentReport;

public class SearchTest extends ExtentReport {
	Base base = new Base();
	public static Logger log = LogManager.getLogger(ExtentReport.class.getName());

	Login login;
	Dashboard dashboard;

	@BeforeTest
	public void initialize() throws IOException {
		base.initializedriver();
		System.out.println("Driver is initizlized");
		System.out.println("Navigate");
		// methodsToRun = Base.webAccessTestCase();
	}

	@Test
	public void completeFlow() throws IOException, InterruptedException {
		Base.webdriver.get(Base.webconfig.getProperty("url"));
		test = extent.createTest("Complete Flow Test");
		login = new Login(Base.webdriver);
		// ArrayList<String> a=b.webaccess("Login");
		login.SendEmail();
		test.log(Status.INFO, "Entered registered email address");

		login.SendPassword();
		test.log(Status.INFO, "Entered registered password");

		login.Submit();
		test.log(Status.INFO, "Clicked on Login button");

		test.log(Status.INFO, "Successfull login");

		dashboard = new Dashboard(Base.webdriver);
		// dashboard.accesTableColumn();
		Thread.sleep(5000);
		
		dashboard.search();
		test.log(Status.INFO, "Successfull search");
		Thread.sleep(4000);

		dashboard.detail_first();
		test.log(Status.INFO, "navigated to error detail page of 1st order");
		Thread.sleep(5000);

		dashboard.detailAssert_EmptydtFile();
		test.log(Status.PASS, "Assertion of error detail page of 1st order is Successfull");
		Thread.sleep(2000);

		dashboard.back();
		test.log(Status.INFO, "navigated back to List of error page");
		Thread.sleep(5000);

		dashboard.delete_first();
		test.log(Status.INFO, "Delete 1st error of 'List of error' page ");
		login.driver.navigate().refresh();
		Thread.sleep(5000);

		dashboard.deleteAssert();
		test.log(Status.PASS, "Asssertion of Delete 1st error of 'List of error' page is Successfull");
		Thread.sleep(5000);

		dashboard.search();
		Thread.sleep(2000);
		dashboard.deletAll();
		test.log(Status.INFO, "Delete all order of 1st page");
		Thread.sleep(5000);

		dashboard.deletAllAssertion();
		test.log(Status.PASS, "Assertion of delete all");
		Thread.sleep(5000);

		dashboard.logout();
		test.log(Status.PASS, "Clicked on LogOut");

		Thread.sleep(5000);
		test.log(Status.INFO, "Successfull logout");

		dashboard.logout_assertion();
		test.log(Status.INFO, "Logout assert");
	}

	@AfterTest
	public void teardown() {
		Base.webdriver.close();
	}

}
