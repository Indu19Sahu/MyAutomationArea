package com.qa.atlasoil.restassured.testsuite;

import java.util.Properties;
import org.apache.oltu.oauth2.client.OAuthClient;
import org.apache.oltu.oauth2.client.URLConnectionClient;
import org.apache.oltu.oauth2.client.request.OAuthClientRequest;
import org.apache.oltu.oauth2.client.response.OAuthJSONAccessTokenResponse;
import org.apache.oltu.oauth2.common.OAuth;
import org.apache.oltu.oauth2.common.message.types.GrantType;

import com.qa.atlasoil.base.Base;
import com.qa.atlasoil.constant.Field;

public class GetAuthTokenForECommerce {
	public static Properties prop = new Properties();
	Base base = new Base();
	

	
	public static void getToken() {
	Base.initializeProperty();
	
	try {
		OAuthClient client = new OAuthClient(new URLConnectionClient());

		OAuthClientRequest request = OAuthClientRequest.tokenLocation(Base.payloadconfig.getProperty(Field.URI))
				.setGrantType(GrantType.CLIENT_CREDENTIALS).setClientId(Base.payloadconfig.getProperty(Field.CLIENT_ID))
				.setClientSecret(Base.payloadconfig.getProperty(Field.CLIENT_SECRET))
				.setParameter("resource", Base.payloadconfig.getProperty(Field.RESOURCE)).buildBodyMessage();
		

		Base.token = client.accessToken(request, OAuth.HttpMethod.POST, OAuthJSONAccessTokenResponse.class)
				.getAccessToken();
		
	} catch (Exception exn) {
		exn.printStackTrace();
	}
	
	}
}
