package com.qa.atlasoil.restassured.testsuite;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.qa.atlasoil.base.Base;
import com.qa.atlasoil.constant.Field;
import com.qa.atlasoil.reports.ExtentReport;
import com.qa.atlasoil.util.jsonGenerator.DTJpgJsonGenerator;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.testng.Assert;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class FNNRequestDTjpg extends ExtentReport {
	Base base = new Base();
	DTJpgJsonGenerator dt = new DTJpgJsonGenerator();

	@Test
	public void post() throws IOException {
		Base.initializeProperty();

		try {
			test = extent.createTest("Sending DT(jpg) Test");
			RestAssured.baseURI = Base.payloadconfig.getProperty(Field.ENDPOINT_DEV);
			dt.jsonGenerator();

			Thread.sleep(5000);

			GetAuthTokenForECommerce.getToken();
			
			String payload = new String(Files.readAllBytes(Paths.get(Base.mainconfig.getProperty(Field.JSON_PAYLOAD_PATH))));
			// System.out.println(payload);
			RequestSpecification request = RestAssured.given();
			
			request.header("Content-type", Field.CONTENT_TYPE);
			// request.header("aeg-sas-key",prop.getProperty("aeg-sas-key(dev)"));
			request.header("Ocp-Apim-Trace", "true");
			request.header("Ocp-Apim-Subscription-Key", Base.payloadconfig.getProperty(Field.SUBSCRIPTION_KEY_DEV));
			request.header("Authorization", "Bearer "+Base.token);
			request.body(payload);
			
			System.out.println("Creating DT(jpg)");
			test.log(Status.INFO, "Creating DT(jpg)");
			Response response = request.post(Base.payloadconfig.getProperty(Field.RESOURCE_DEV));
			
			Thread.sleep(20000);
			int statusCode = response.getStatusCode();
			System.out.println("Status Code: " + statusCode);

			Assert.assertEquals(statusCode, 200);
			System.out.println("Successfully DT(jpg) sent with status code 200");
			test.log(Status.PASS, "Successfully DT(jpg) sent with status code 200");
			// String responseBody = response.getBody().asString();

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
