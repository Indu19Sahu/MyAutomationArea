package com.qa.atlasoil.restassured.testsuite;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.qa.atlasoil.base.Base;
import com.qa.atlasoil.constant.Field;
import com.qa.atlasoil.reports.ExtentReport;
import com.qa.atlasoil.util.jsonGenerator.DTPngJsonGenerator;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.testng.Assert;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class FNNRequestDTpng extends ExtentReport {
	Base base = new Base();
	DTPngJsonGenerator dt = new DTPngJsonGenerator();

	@Test
	public void post() throws IOException {
		Base.initializeProperty();

		try {
			test = extent.createTest("Sending DT(png) Test");
			RestAssured.baseURI = Base.payloadconfig.getProperty(Field.ENDPOINT_DEV);

			dt.jsonGenerator();
			Thread.sleep(5000);

			GetAuthTokenForECommerce.getToken();
			
			String payload = new String(Files.readAllBytes(Paths.get(Base.mainconfig.getProperty(Field.JSON_PAYLOAD_PATH))));
			// System.out.println(payload);
			RequestSpecification request = RestAssured.given();
			
			request.header("Content-type", Field.CONTENT_TYPE);
			request.header("Ocp-Apim-Trace", "true");
			request.header("Ocp-Apim-Subscription-Key", Base.payloadconfig.getProperty(Field.SUBSCRIPTION_KEY_DEV));
			request.header("Authorization", "Bearer "+Base.token);
			request.body(payload);
			
			System.out.println("Creating DT(png)");
			test.log(Status.INFO, "Creating DT(png)");
			
			Response response = request.post(Base.payloadconfig.getProperty(Field.RESOURCE_DEV));
			
			Thread.sleep(20000);
			int statusCode = response.getStatusCode();
			System.out.println("Status Code: " + statusCode);

			Assert.assertEquals(statusCode, 200);
			System.out.println("Successfully DT(png) sent with status code 200");
			test.log(Status.PASS, "Successfully DT(png) sent with status code 200");
			// String responseBody=response.getBody().asString();
			// System.out.print(responseBody);

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
